const audioMap = {
  draw: null,
  holster: null,
};

function get(id) {
  if (!audioMap[id]) {
    audioMap[id] = document.getElementById(id);
  }
  return audioMap[id];
}

function safePlay(el) {
  if (!el) return;
  try {
    el.currentTime = 0;
    if (el.readyState < 2) el.load();
    const p = el.play();
    if (p && typeof p.catch === "function") {
      p.catch(() => { /* ignore autoplay/gesture warnings in logs */ });
    }
  } catch (e) {
  }
}

function setVolumeAll(v) {
  Object.keys(audioMap).forEach((k) => {
    const el = get(k);
    if (el) el.volume = v;
  });
}

window.addEventListener("DOMContentLoaded", () => {
  ["draw", "holster"].forEach((id) => {
    const el = get(id);
    if (el) {
      el.volume = 1.0;
      try { el.load(); } catch (_) {}
    }
  });
});

window.addEventListener("message", (event) => {
  const data = event.data || {};
  if (!data.action) return;

  switch (data.action) {
    case "play": {
      const el = get(data.sound);
      safePlay(el);
      break;
    }
    case "setVolume": {
      const vol = Math.max(0, Math.min(1, Number(data.volume)));
      setVolumeAll(isNaN(vol) ? 1.0 : vol);
      break;
    }
    default:
      break;
  }
});
