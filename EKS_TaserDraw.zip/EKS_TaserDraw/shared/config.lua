Config = {}

-- Check rate (ms)

Config.PollInterval = 120

-- Taser weapons

Config.TaserWeapons = { 'WEAPON_STUNGUN', 'WEAPON_STUNGUN_MP' }

-- Match texture too? (false = drawable-only)

Config.RequireTextureMatch = false

-- Swaps (A ? B). You MUST set gender = "male" or "female".
-- component/prop can be the slot number (recommended) or "id#".

Config.List = {
    { component = 8, holstered = 2, drawn = 3, gender = "male" },  
    { component = 11, holstered = 21, drawn = 22, gender = "female" },
    { component = 7,  holstered = 10, drawn = 11, gender = "male"  }, 
    { component = 7,  holstered = 78, drawn = 80, gender = "female"},  

    -- Props example (A?B, never cleared):
    -- { prop = 0, holstered = 12, drawn = 14, gender = "male" },
    -- { prop = 0, holstered = 12, drawn = 14, gender = "female" },
}
