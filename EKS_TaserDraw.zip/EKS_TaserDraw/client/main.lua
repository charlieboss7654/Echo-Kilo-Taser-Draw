local isTaserOut = false
local storedOriginal = {}  -- [i] = exact saved state for Config.List[i]
local lastModel = 0

local function getId(v)
    if type(v) == "number" then return v end
    if type(v) == "string" then
        local n = tonumber(v:match("id(%d+)") or v)
        return n or 0
    end
    return 0
end

local function isFreemodeMale(ped)   return GetEntityModel(ped) == `mp_m_freemode_01` end
local function isFreemodeFemale(ped) return GetEntityModel(ped) == `mp_f_freemode_01` end

local function genderMatches(ped, g)
    if type(g) ~= "string" then return false end
    g = g:lower()
    if g == "male" then return isFreemodeMale(ped) end
    if g == "female" then return isFreemodeFemale(ped) end
    return false
end

local function isTaserWeapon(hash)
    for _, name in ipairs(Config.TaserWeapons or {}) do
        if hash == GetHashKey(name) then return true end
    end
    return false
end

local function getCurrentComponent(ped, id)
    return {
        type="component",
        id=id,
        drawable=GetPedDrawableVariation(ped, id),
        texture=GetPedTextureVariation(ped, id),
        palette=GetPedPaletteVariation(ped, id)
    }
end

local function getCurrentProp(ped, id)
    return {
        type="prop",
        id=id,
        drawable=GetPedPropIndex(ped, id),          
        texture=GetPedPropTextureIndex(ped, id)
    }
end

local function getCurrent(ped, rule)
    if rule._type == "component" then
        return getCurrentComponent(ped, rule._id)
    else
        return getCurrentProp(ped, rule._id)
    end
end

local function matchesHolstered(current, rule)
    if current.drawable ~= rule.holstered then return false end
    if Config.RequireTextureMatch then
        local holtex = rule.hol_tex or 0
        return current.texture == holtex
    end
    return true
end

local function applyDrawn(ped, rule)
    local drawDrawable = rule.drawn
    local drawTex = rule.drawn_tex or 0
    if rule._type == "component" then
        SetPedComponentVariation(ped, rule._id, drawDrawable, drawTex, 0)
    else
        SetPedPropIndex(ped, rule._id, drawDrawable, drawTex, true)
    end
end

local function restoreOriginal(ped, original)
    if original.type == "component" then
        SetPedComponentVariation(ped, original.id, original.drawable, original.texture, original.palette or 0)
    else
        if original.drawable == -1 then
            ClearPedProp(ped, original.id)
        else
            SetPedPropIndex(ped, original.id, original.drawable, original.texture, true)
        end
    end
end

local function playSound(which) SendNUIMessage({ action='play', sound=which }) end

local function normalizeRules()
    for i, rule in ipairs(Config.List or {}) do
        if rule.component ~= nil or rule.compentent ~= nil or rule.comp ~= nil then
            local raw = rule.component or rule.compentent or rule.comp
            rule._type = "component"
            rule._id   = getId(raw)
        elseif rule.prop ~= nil then
            rule._type = "prop"
            rule._id   = getId(rule.prop)
        else
            rule._type = "component"
            rule._id   = getId(rule.id)
        end

        rule.hol_tex  = rule.hol_tex or 0
        rule.drawn_tex= rule.drawn_tex or 0

        local g = type(rule.gender) == "string" and rule.gender:lower() or ""
        if not (g == "male" or g == "female") then
            rule._skip = true
        end
    end
end

local function onDraw(ped)
    playSound('draw')
    for i, rule in ipairs(Config.List or {}) do
        if not rule._skip and rule._id and rule._id >= 0 and genderMatches(ped, rule.gender) then
            local current = getCurrent(ped, rule)
            if matchesHolstered(current, rule) then
                storedOriginal[i] = current
                applyDrawn(ped, rule)
            end
        end
    end
end

local function onHolster(ped)
    playSound('holster')
    for _, original in pairs(storedOriginal) do
        restoreOriginal(ped, original)
    end
    storedOriginal = {}
end

local function checkModelChange(ped)
    local model = GetEntityModel(ped)
    if model ~= lastModel then
        storedOriginal = {}
        lastModel = model
    end
end

CreateThread(function()
    Wait(200)
    normalizeRules()
    lastModel = GetEntityModel(PlayerPedId())

    while true do
        local ped = PlayerPedId()
        checkModelChange(ped)

        local selected = GetSelectedPedWeapon(ped)
        local nowOut = isTaserWeapon(selected)

        if nowOut and not isTaserOut then
            isTaserOut = true
            onDraw(ped)
        elseif not nowOut and isTaserOut then
            isTaserOut = false
            onHolster(ped)
        end

        Wait(Config.PollInterval or 150)
    end
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    local ped = PlayerPedId()
    for _, original in pairs(storedOriginal) do
        restoreOriginal(ped, original)
    end
end)
