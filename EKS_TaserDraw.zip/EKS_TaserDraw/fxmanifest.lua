fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'EKS Taser Draw'
description 'Simple TASER drawing script with realistic sound effects!'
author 'Cowboy - Echo Kilo Studios'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/script.js',
    'html/sounds/draw.ogg',
    'html/sounds/holster.ogg',
}

shared_script 'shared/config.lua'
client_script 'client/main.lua'
